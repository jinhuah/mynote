package login;

import main.Config;
import main.TestFunctionsBase;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class LoginTest extends TestFunctionsBase {

	private final String baseUrl = Config.BASE_URL;
	private final String username = Config.USERNAME;
	private final String password = Config.PASSWORD;
	private final String navUrl = Config.NAV_URL;

	@Parameters({ "browser", "platform" })
	@Test
	public void loadBrowser(String browser, String platform) {
		System.out.println(" Test - load " + browser + " on " + " " + platform);

		super.setup(browser, platform);
	}

	@Override
	@Test
	public void login() {
		System.out.println(" Test - Login success");

		// Slight sleep while wait for login page load
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println("Sleep interrupted: " + e.getCause());
		}

		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys(username);
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.linkText(" Login ")).click();

		// Slight sleep while wait for login to complete
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println("Sleep interrupted: " + e.getCause());
		}

		// Login should be successful so header & tabs will be displayed
		Assert.assertTrue(driver.findElement(By.id("header")).isDisplayed(),
				"Header not displayed, therefore login unsuccessful");
		Assert.assertTrue(driver.findElement(By.id("tab_panel")).isDisplayed(),
				"Tab Panel not displayed, therefore login unsuccessful");

		driver.findElement(By.id("logout")).click();

	}

	@Test
	public void loginCookie() {
		System.out.println(" Test - Login Cookie");

		super.login();

		// Navigate away then back to check Cookie storage
		driver.get(navUrl);

		// Slight sleep while wait for login to complete
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println("Sleep interrupted: " + e.getCause());
		}

		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
				.matches("^[\\s\\S]*Google Search[\\s\\S]*$"));
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
				.matches("^[\\s\\S]*I'm Feeling Lucky[\\s\\S]*$"));

		driver.get(baseUrl);

		// Slight sleep while wait for login page load
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			System.out.println("Sleep interrupted: " + e.getCause());
		}

		Assert.assertTrue(driver.findElement(By.id("header")).isDisplayed(),
				"Header not displayed, therefore Navigate back unsuccessful");
		Assert.assertTrue(driver.findElement(By.id("tab_panel")).isDisplayed(),
				"Tab Panel not displayed, therefore login unsuccessful");

		driver.findElement(By.id("logout")).click();

	}

	@Parameters({ "browser", "platform" })
	@Test
	// This test only works on Firefox Linux
	public void loginCookieDelete(String browser, String platform) {
		System.out.println("Test - Login Cookie Delete");

		if (browser.contains("firefox") && browser.contains("Linux")) {

			super.login();
			JavascriptExecutor js;
			if (driver instanceof JavascriptExecutor) {
				js = (JavascriptExecutor) driver;
				js.executeScript("document.cookie='JSESSIONID=null;expires='+new Date(0).toUTCString()+';path=/saiku'");
			}

			driver.findElement(By.id("open_query")).click();

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Sleep interrupted: " + e.getCause());
			}

			Alert alert = driver.switchTo().alert();
			alert.dismiss();

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				System.out.println("Sleep interrupted: " + e.getCause());
			}

			Assert.assertTrue(isElementPresent(By.id("ui-dialog-title-1")),
					"Dialog not found");
			Assert.assertFalse(isElementPresent(By.id("tab_panel")),
					"Tab Panel displayed, therefore logout unsuccessful");
			Assert.assertTrue(driver.findElement(By.cssSelector("BODY"))
					.getText().matches("^[\\s\\S]*Username[\\s\\S]*$"));
			Assert.assertTrue(driver.findElement(By.cssSelector("BODY"))
					.getText().matches("^[\\s\\S]*Password[\\s\\S]*$"));

			driver.findElement(By.id("logout")).click();
		}
	}

	@Test
	public void logout() {
		System.out.println(" Test - Logout successful");

		super.login();

		driver.findElement(By.id("logout")).click();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println("Sleep interrupted: " + e.getCause());
		}

		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
				.matches("^[\\s\\S]*Username[\\s\\S]*$"));
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
				.matches("^[\\s\\S]*Password[\\s\\S]*$"));
		Assert.assertFalse(isElementPresent(By.id("tab_panel")),
				"Tab Panel displayed, therefore logout unsuccessful");

	}

	@Test(enabled=false)
	public void loginFail() {
		System.out.println(" Test - Login Failed");

		if (isElementPresent(By.id("ui-dialog-title-1"))) {
			driver.findElement(By.id("username")).clear();
			driver.findElement(By.id("username")).sendKeys("test-user");
			driver.findElement(By.id("password")).clear();
			driver.findElement(By.id("password")).sendKeys("failure");
			driver.findElement(By.linkText(" Login ")).click();

			// Slight sleep while wait for login to complete
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				System.out.println("Sleep interrupted: " + e.getCause());
			}

			// Header shouldn't be displayed as login should fail
			Assert.assertFalse(driver.findElement(By.id("header"))
					.isDisplayed(),
					"Header is displayed, therefore login succesful");

		} else {
			Assert.fail("Login dialogue not found");
		}
	}

	@Override
	@AfterClass
	public void closeBrowser() throws Exception {
		System.out.println("Clean up - Close the browser");
		super.closeBrowser();
	}
}
