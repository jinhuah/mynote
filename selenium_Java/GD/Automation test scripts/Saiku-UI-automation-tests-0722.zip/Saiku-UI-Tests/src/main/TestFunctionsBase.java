package main;

import static org.testng.Assert.fail;

import java.awt.Robot;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

/**
 * This class provides a number of functions which will be frequently called
 * by other classes
 * @author Jinhua Huang
 */
public class TestFunctionsBase {

	protected String browser;
	protected String platform;
	protected WebDriver driver;
	protected WebDriverWait wait;
	private final String baseUrl = Config.BASE_URL;
	private final String seleniumUrl = Config.SELENIUM_URL;
	private final String username = Config.USERNAME;
	private final String password = Config.PASSWORD;
	private boolean acceptNextAlert = true;
	protected final StringBuffer verificationErrors = new StringBuffer();
	private final DesiredCapabilities capabilities = new DesiredCapabilities();
	private final int sp[] = Config.START_POINT;
	private final int dm[] = Config.DIMESION;

	/**
	 * A function of configuring and starting a browser
	 */
	public void setup(String browser, String platform) {
		System.out.println("setup"+browser+platform);

		//Browsers
		if(browser.equalsIgnoreCase("firefox")){
			capabilities.setBrowserName(DesiredCapabilities.firefox().getBrowserName());
		}

		if(browser.equalsIgnoreCase("iexplore")){
			capabilities.setBrowserName(DesiredCapabilities.internetExplorer().getBrowserName());
		}

		if(browser.equalsIgnoreCase("chrome")){
			capabilities.setBrowserName(DesiredCapabilities.chrome().getBrowserName());
		}

		//Platforms
		if(platform.equalsIgnoreCase("Windows")){
			capabilities.setPlatform(org.openqa.selenium.Platform.WINDOWS);
		}

		if(platform.equalsIgnoreCase("Linux")){
			capabilities.setPlatform(org.openqa.selenium.Platform.LINUX);
		}

		try {
			URL url = new URL(seleniumUrl);
			driver = new RemoteWebDriver(url, capabilities);

			driver.manage().window().setPosition(new Point(sp[0],sp[1]));
			driver.manage().window().setSize(new Dimension(dm[0],dm[1]));

			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(5, TimeUnit.SECONDS);

			driver.get(baseUrl);
			wait = new WebDriverWait(driver, 60);
		}
		catch (MalformedURLException ex) {
			Logger.getLogger(TestFunctionsBase.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void login() {
		System.out.println("Start to login");

		for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (isElementPresent(By.id("ui-dialog-title-1"))) break; } catch (Exception e) {}

			try {
				Thread.sleep(1000);
			} catch (InterruptedException ex) {
				System.out.println("Interrupted: " + ex.getCause());
			}
		}

		// Check dialog is shown along with Login Text
		if(isElementPresent(By.id("ui-dialog-title-1")))
		{
			getElement(By.id("username")).clear();
			getElement(By.id("username")).sendKeys(username);
			getElement(By.id("password")).clear();
			getElement(By.id("password")).sendKeys(password);
			getElement(By.linkText(" Login ")).click();

			// Slight sleep while wait for login to complete
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				System.out.println("Sleep interrupted: " + e.getCause());
			}

			// Login should be successful so header & tabs will be displayed
			Assert.assertTrue(getElement(By.id("header")).isDisplayed(),"Header not displayed, therefore login unsuccessful" );
			Assert.assertTrue(getElement(By.id("tab_panel")).isDisplayed(), "Tab Panel not displayed, therefore login unsuccessful");
		}
		else
		{
			fail("Login dialogue not found");
		}
		System.out.println("Login successfully");
	}

	// Create a query by drag and drop "Product Family" and "Store Name" to Columns and Rows fields
	public void crtQuery_DragandDrop() throws Exception {

		driver.findElement(By.id("new_query")).click();
		new Select(driver.findElement(By.cssSelector("select.cubes"))).selectByVisibleText("Warehouse");
		driver.findElement(By.linkText("Product")).click();

		Robot r = new Robot();
		r.mouseMove(0,0);

		// Drag "Product Family" and drop into the column field
		WebElement selection1 = driver.findElement(By.linkText("Product Family"));
		WebElement target1 =  driver.findElement(By.xpath("//html/body/div[9]/div/div/div/div[2]/div/div/div/div[2]/ul")); // This is Columns field
		dragAndDrop(selection1,target1);

		// Drag "Store Name" and drop into the row field
		driver.findElement(By.linkText("Store")).click();

		r.mouseMove(0,0);

		WebElement selection2 = driver.findElement(By.linkText("Store Name"));
		WebElement target2 = driver.findElement(By.xpath("//html/body/div[9]/div/div/div/div[2]/div/div/div[2]/div[2]/ul")); // This is Row field
		dragAndDrop(selection2,target2);

		Thread.sleep(2000);
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Drink[\\s\\S]*$"));
		Assert.assertFalse(driver.findElement(By.cssSelector("BODY")).getText()
				.contains("You need to put at least"));
	}

	// Create a query by clicking "Product Family" and "Store Name"
	public void crtQuery() throws Exception {

		driver.findElement(By.id("new_query")).click();
		new Select(driver.findElement(By.cssSelector("select.cubes"))).selectByVisibleText("Warehouse");

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Product")));
		driver.findElement(By.linkText("Product")).click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Product Family")));
		driver.findElement(By.linkText("Product Family")).click();

		Thread.sleep(1000);
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
				.contains("You need to put at least"),"No texts \"You need to put at least ...\" appear.");

		driver.findElement(By.linkText("Store")).click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Store Name")));
		driver.findElement(By.linkText("Store Name")).click();

		Thread.sleep(2000);
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText()
				.matches("^[\\s\\S]*Drink[\\s\\S]*$"),"No query output displays after query creation.");
		Assert.assertFalse(driver.findElement(By.cssSelector("BODY")).getText()
				.contains("You need to put at least"));
	}

	public void dragAndDrop(WebElement src, WebElement des)
	{
		Actions act = new Actions(driver);
		act.clickAndHold(src).build().perform();
		act.moveToElement(des).build().perform();
		act.release(des).build().perform();
	}

	public void closeBrowser() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}


	protected boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private WebElement getElement(By by) {
		try {
			return driver.findElement(by);
		} catch (NoSuchElementException e) {
			return null;
		}
	}


	@SuppressWarnings("unused")
	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alert.getText();
		} finally {
			acceptNextAlert = true;
		}
	}

}
