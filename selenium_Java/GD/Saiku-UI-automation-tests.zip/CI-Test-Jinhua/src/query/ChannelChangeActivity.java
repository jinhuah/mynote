/*
 *   Copyright 2013 Genius Digital Ltd
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package query;

import static org.testng.Assert.fail;

import java.awt.Robot;

import main.TestFunctionsBase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * This class tests queries generated in "Channel Change Activity" cube, it contains the following tests.
 * 
 *
 * 
 */

public class ChannelChangeActivity extends TestFunctionsBase {

	/**
	 * Initial setup to load browser, access url and login
	 * @param browser - The browser to run the test on
	 * @param platform - The platform to run the test on
	 */
	@Override
	@Parameters({"browser", "platform"})
	@BeforeClass
	public void setup(String browser, String platform){
		System.out.println(browser +" " + platform);
		super.setup(browser,platform);
		super.login();
		//		super.refreshCube();
	}

	/**
	 * Columns: Channel - Channel
	 * Rows: Date - Day
	 */
	@Test(enabled=false)
	public void cca001_columns_Channel_rows_Day() throws Exception {

		driver.findElement(By.id("new_query")).click();
		new Select(driver.findElement(By.cssSelector("select.cubes"))).selectByVisibleText("Channel Change Activity"); 	//Data from CI
		driver.findElement(By.linkText("Channel")).click();  //Data from CI

		Robot r = new Robot();
		r.mouseMove(0,0);

		// Drag "Channel" and drop into the column field
		WebElement selection1 = driver.findElement(By.cssSelector("a[rel='[Channel].[Channel]']"));  //Data from CI
		WebElement target1 = driver.findElement(By.cssSelector(".columns > ul:nth-child(1)")); // This is Columns field

		dragAndDrop(selection1,target1);

		// Click "Date" folder
		driver.findElement(By.linkText("Date")).click();	//Data from CI

		r.mouseMove(0,0);

		// Drag "Day" and drop into the row field
		WebElement selection2 = driver.findElement(By.linkText("Day"));  // This is Columns field  //Data from CI
		WebElement target2 = driver.findElement(By.cssSelector(".rows > ul:nth-child(1)")); // This is Row field
		dragAndDrop(selection2,target2);

		// Wait until "info" element is visible
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("workspace_results_info")));

		// Verify the channel name "ABC" is displayed
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*ABC[\\s\\S]*$"));	//Data from Telbo

		// Verify result info is correct
		Assert.assertTrue(driver.findElement(By.className("workspace_results_info")).getText().contains("126 x 37"));	//Data from Telbo
	}

	/**
	 * Columns: Devices Changing Channel
	 * Rows: Channel - Channel
	 * Filters: Day(Select a day to filter) - 2013-06-20
	 * 1. Run the query
	 * 2. Then Sorted by Devices
	 */
	@Test(enabled=false, groups="DragandDrop")
	public void cca002_columns_Devices_rows_Channel_filters_givenDay__sort_by_Devices() throws Exception {

		driver.findElement(By.id("new_query")).click();
		new Select(driver.findElement(By.cssSelector("select.cubes"))).selectByVisibleText("Channel Change Activity"); 	//Data from CI

		// Stop automation execution query
		driver.findElement(By.cssSelector("a[title='Automatic execution']")).click();

		Robot r = new Robot();
		r.mouseMove(0,0);

		// Drag "Devices Changing Channel" and drop into the row field
		WebElement selection1 = driver.findElement(By.linkText("Devices Changing Channel"));  // This is Columns field  //Data from CI
		WebElement target1 = driver.findElement(By.cssSelector(".columns > ul:nth-child(1)")); // This is Rows field
		dragAndDrop(selection1,target1);

		r.mouseMove(0,0);

		driver.findElement(By.linkText("Channel")).click();  //Data from CI

		// Drag "Channel" and drop into the column field
		WebElement selection2 = driver.findElement(By.cssSelector("a[rel='[Channel].[Channel]']"));  //Data from CI
		WebElement target2 = driver.findElement(By.cssSelector(".rows > ul:nth-child(1)")); // This is Columns field
		dragAndDrop(selection2,target2);

		// Click "Date" folder
		driver.findElement(By.linkText("Date")).click();	//Data from CI

		// Drag "Day" and drop into the row field
		WebElement selection3 = driver.findElement(By.linkText("Day"));  // This is Columns field  //Data from CI
		WebElement target3 = driver.findElement(By.cssSelector("div.fields_list_body.filter > ul.connectable.ui-sortable")); // This is Rows field
		dragAndDrop(selection3,target3);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("available_selections")));

		driver.findElement(By.id("filter_selections")).clear();
		driver.findElement(By.id("filter_selections")).sendKeys("2013-06-20");	//Data from Telbo
		driver.findElement(By.id("ui-active-menuitem")).click();
		driver.findElement(By.linkText(" OK ")).click();

		// Click "Run query" button
		driver.findElement(By.cssSelector("a[title='Run query']")).click();

		// Wait until "info" element is visible
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("workspace_results_info")));

		// Verify a channel name is displayed
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*ABC[\\s\\S]*$"));	//Data from Telbo

		// Verify result info is correct
		Assert.assertTrue(driver.findElement(By.className("workspace_results_info")).getText().matches("^[\\s\\S]* 2 x 126 [\\s\\S]*$"));	//Data from Telbo

		// Sort by Device class="sort BASC"
		driver.findElement(By.cssSelector("span.sort.none")).click();
		driver.findElement(By.cssSelector("span.sort.BASC")).click();

		// Click "Run query" button
		driver.findElement(By.cssSelector("a[title='Run query']")).click();

		Assert.assertTrue(driver.findElement(By.cssSelector("div[rel='1:0']")).getText().matches("Tele Curacao"));	//Data from Telbo
		Assert.assertTrue(driver.findElement(By.cssSelector("div[rel='2:0']")).getText().matches("Nederland 1"));	//Data from Telbo
		Assert.assertTrue(driver.findElement(By.cssSelector("div[rel='3:0']")).getText().matches("BVN-TV"));	//Data from Telbo
	}


	/**
	 * Columns: Channel
	 * Rows: Hour
	 * Filters: Day(Select a day to filter) - 2013-06-20
	 * 1. Run the query
	 * 2. Then Sorted by Devices
	 */
	@Test(enabled=false, groups="DragandDrop")
	public void cca003_columns_Channel_rows_Hour_filters_givenDay__display_line() throws Exception {

		driver.findElement(By.id("new_query")).click();
		new Select(driver.findElement(By.cssSelector("select.cubes"))).selectByVisibleText("Channel Change Activity"); 	//Data from CI

		// Stop automation execution query
		driver.findElement(By.cssSelector("a[title='Automatic execution']")).click();

		driver.findElement(By.linkText("Channel")).click();  //Data from CI

		Robot r = new Robot();
		r.mouseMove(0,0);

		// Drag "Channel" and drop into the row field
		WebElement selection1 = driver.findElement(By.cssSelector("a[rel='[Channel].[Channel]']"));   //Data from CI
		WebElement target1 = driver.findElement(By.cssSelector(".columns > ul:nth-child(1)"));  // This is Columns field
		dragAndDrop(selection1,target1);

		r.mouseMove(0,0);

		// Click "Time" folder
		driver.findElement(By.linkText("Time")).click();	//Data from CI

		// Drag "Channel" and drop into the column field
		WebElement selection2 = driver.findElement(By.linkText("Hour"));  //Data from CI
		WebElement target2 = driver.findElement(By.cssSelector(".rows > ul:nth-child(1)")); // This is Rows field
		dragAndDrop(selection2,target2);

		// Click "Date" folder
		driver.findElement(By.linkText("Date")).click();	//Data from CI

		// Drag "Day" and drop into the row field
		WebElement selection3 = driver.findElement(By.linkText("Day"));  //Data from CI
		WebElement target3 = driver.findElement(By.cssSelector("div.fields_list_body.filter > ul.connectable.ui-sortable")); // This is Filter field
		dragAndDrop(selection3,target3);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("available_selections")));

		driver.findElement(By.id("filter_selections")).clear();
		driver.findElement(By.id("filter_selections")).sendKeys("2013-06-20");	//Data from Telbo
		driver.findElement(By.id("ui-active-menuitem")).click();
		driver.findElement(By.linkText(" OK ")).click();

		// Click "Run query" button
		driver.findElement(By.cssSelector("a[title='Run query']")).click();

		// Wait until "info" element is visible
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("workspace_results_info")));

		// Verify a channel name is displayed
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*ABC[\\s\\S]*$"));	//Data from Telbo

		// Verify result info is correct
		Assert.assertTrue(driver.findElement(By.className("workspace_results_info")).getText().matches("^[\\s\\S]* 126 [\\s\\S]*$"));	//Data from Telbo

		// Sort by Device class="sort BASC"
		driver.findElement(By.cssSelector("a[title='Toggle Chart']")).click();
		driver.findElement(By.cssSelector("a[title='Line']")).click();

		// Click "Run query" button
		driver.findElement(By.cssSelector("a[title='Run query']")).click();

		// Wait the graph area is visible
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("rect[pointer-events='all']")));

		//The test ends here, but a screenshot will be taken.
	}

	/**
	 * Columns: (EXP) Non-Zap Changes, (EXP) Zap Changes, Number of Changes
	 * Rows: Channel - Channel
	 * 1. Run the query
	 * 2. Check : (EXP) Non-Zap Changes + (EXP) Zap Changes = Number of Changes
	 */
	@Test(groups="DragandDrop")
	public void cca004_columns_NonZapChanges_ZapChanges_NumberOfChanges_rows_Channel__comparison() throws Exception {

		driver.findElement(By.id("new_query")).click();
		new Select(driver.findElement(By.cssSelector("select.cubes"))).selectByVisibleText("Channel Change Activity"); 	//Data from CI

		// Stop automation execution query
		driver.findElement(By.cssSelector("a[title='Automatic execution']")).click();

		Robot r = new Robot();
		r.mouseMove(0,0);

		// Drag "Devices Changing Channel" and drop into the row field
		WebElement selection1 = driver.findElement(By.linkText("(EXP) Non-Zap Changes"));  // This is Columns field  //Data from CI
		WebElement target1 = driver.findElement(By.cssSelector(".columns > ul:nth-child(1)")); // This is Rows field
		dragAndDrop(selection1,target1);

		WebElement selection12 = driver.findElement(By.linkText("(EXP) Zap Changes"));  // This is Columns field  //Data from CI
		dragAndDrop(selection12,target1);

		WebElement selection13 = driver.findElement(By.linkText("Number of Changes"));  // This is Columns field  //Data from CI
		dragAndDrop(selection13,target1);

		r.mouseMove(0,0);

		driver.findElement(By.linkText("Channel")).click();  //Data from CI

		// Drag "Channel" and drop into the column field
		WebElement selection2 = driver.findElement(By.cssSelector("a[rel='[Channel].[Channel]']"));  //Data from CI
		WebElement target2 = driver.findElement(By.cssSelector(".rows > ul:nth-child(1)")); // This is Columns field
		dragAndDrop(selection2,target2);

		// Click "Run query" button
		driver.findElement(By.cssSelector("a[title='Run query']")).click();

		// Wait until "info" element is visible
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("workspace_results_info")));

		// Verify a channel name is displayed
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*ABC[\\s\\S]*$"));	//Data from Telbo

		// Verify result info is correct
		Assert.assertTrue(driver.findElement(By.className("workspace_results_info")).getText().matches("^[\\s\\S]* x 126 [\\s\\S]*$"));	//Data from Telbo

		// Sort by "Number of Changes"
		driver.findElement(By.cssSelector("span.sort.none")).click();
		driver.findElement(By.cssSelector("span.sort.BASC")).click();

		// Click "Run query" button
		driver.findElement(By.cssSelector("a[title='Run query']")).click();

		// Verify top three channels are correct
		Assert.assertTrue(driver.findElement(By.cssSelector("th.row div[rel='1:0']")).getText().matches("Tourist TV"));	//Data from Telbo
		Assert.assertTrue(driver.findElement(By.cssSelector("th.row div[rel='2:0']")).getText().matches("Tele Curacao"));	//Data from Telbo
		Assert.assertTrue(driver.findElement(By.cssSelector("th.row div[rel='3:0']")).getText().matches("Nederland 1"));	//Data from Telbo

		// Verify: (EXP) Non-Zap Changes + (EXP) Zap Changes = Number of Changes

		// Pick up the strings
		String stg1 = driver.findElement(By.cssSelector("td.data div[rel='0:0']")).getText();
		String stg2 = driver.findElement(By.cssSelector("td.data div[rel='1:0']")).getText();
		String stg3 = driver.findElement(By.cssSelector("td.data div[rel='2:0']")).getText();

		// Convert the strings to long numbers
		long num1 = Long.valueOf(stg1.replaceAll(",", "").toString());
		long num2 = Long.valueOf(stg2.replaceAll(",", "").toString());
		long num3 = Long.valueOf(stg3.replaceAll(",", "").toString());

		// Do a comparison
		if (num3 != (num1 + num2))
			fail ("'(EXP) Non-Zap Changes + (EXP) Zap Changes' not equal to 'Number of Changes'");
	}

	/**
	 * Take a screenshot if a test fails
	 * @param browser - The browser to run the test on
	 * @param platform - The platform to run the test on
	 */
	@Parameters({"browser", "platform"})
	@AfterMethod(alwaysRun = true)
	public void screenshotOnTest(ITestResult result, String browser, String platform) {
		if (result.isSuccess()) {
			super.takeScreenshot(result, browser, platform, "ChannelChangeActivity");
		}
		else {
			super.takeScreenshot(result, browser, platform, "ChannelChangeActivity/failure");
		}

		driver.findElement(By.cssSelector("li.selected > span.close_tab.sprite")).click();
	}

	@Override
	@AfterClass
	public void closeBrowser() throws Exception {
		System.out.println("Clean up - Close the browser");
		super.closeBrowser();
	}

}

