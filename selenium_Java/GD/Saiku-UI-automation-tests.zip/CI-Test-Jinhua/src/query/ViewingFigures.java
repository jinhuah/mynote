/*
 *   Copyright 2013 Genius Digital Ltd
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package query;

import java.awt.Robot;

import main.TestFunctionsBase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * This class tests queries generated in "Viewing Figures" cube, it contains the following tests.
 * 
 *
 * 
 */

public class ViewingFigures extends TestFunctionsBase {

	/**
	 * Initial setup to load browser, access url and login
	 * @param browser - The browser to run the test on
	 * @param platform - The platform to run the test on
	 */
	@Override
	@Parameters({"browser", "platform"})
	@BeforeClass
	public void setup(String browser, String platform){
		System.out.println(browser +" " + platform);
		super.setup(browser,platform);
		super.login();
		super.refreshCube();
	}

	/**
	 * Columns: Channel - Channel
	 * Rows: Date - Day
	 */
	@Test
	public void vf001_Channel_By_Day() throws Exception {

		driver.findElement(By.id("new_query")).click();
		new Select(driver.findElement(By.cssSelector("select.cubes"))).selectByVisibleText("Viewing Figures"); 	//Data from CI
		driver.findElement(By.linkText("Channel")).click();  //Data from CI

		Robot r = new Robot();
		r.mouseMove(0,0);

		// Drag "Channel" and drop into the column field
		WebElement selection1 = driver.findElement(By.cssSelector("a[rel='[Channel].[Channel]']"));  //Data from CI
		WebElement target1 = driver.findElement(By.cssSelector(".columns > ul:nth-child(1)")); // This is Columns field

		dragAndDrop(selection1,target1);

		// Click "Date" folder
		driver.findElement(By.linkText("Date")).click();	//Data from CI

		r.mouseMove(0,0);

		// Drag "Day" and drop into the row field
		WebElement selection2 = driver.findElement(By.linkText("Day"));  // This is Columns field  //Data from CI
		WebElement target2 = driver.findElement(By.cssSelector(".rows > ul:nth-child(1)")); // This is Row field
		dragAndDrop(selection2,target2);

		// Wait until "info" element is visible
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("workspace_results_info")));

		// Verify the channel name "ABC" is displayed
		Assert.assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*ABC[\\s\\S]*$"));	//Data from Telbo

		// Verify result info is correct
		Assert.assertTrue(driver.findElement(By.className("workspace_results_info")).getText().contains("126 x 37"));	//Data from Telbo

	}

	/**
	 * Take a screenshot if a test fails
	 * @param browser - The browser to run the test on
	 * @param platform - The platform to run the test on
	 */
	@Parameters({"browser", "platform"})
	@AfterMethod(alwaysRun = true)
	public void screenshotOnTest(ITestResult result, String browser, String platform) {
		if (result.isSuccess()) {
			super.takeScreenshot(result, browser, platform, "ViewingFigures");
		}
		else {
			super.takeScreenshot(result, browser, platform, "ViewingFigures/failure");
		}

		driver.findElement(By.cssSelector("li.selected > span.close_tab.sprite")).click();
	}

	@Override
	@AfterClass
	public void closeBrowser() throws Exception {
		System.out.println("Clean up - Close the browser");
		super.closeBrowser();
	}

}

