package query;

import java.util.List;

import main.TestFunctionsBase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.util.Strings;


public class CubeLists extends TestFunctionsBase {

	/**
	 * @param args
	 */
	public void channelChangeActivity_Dimension() {

		Strings [] DM_list;

		driver.findElement(By.id("new_query")).click();
		new Select(driver.findElement(By.cssSelector("select.cubes"))).selectByVisibleText("Channel Change Activity");

		// Create an interface WebElement of the div under div with **class as facetContainerDiv** div class="sidebar_inner dimension_tree">
		List<WebElement> allElements = driver.findElements(By.xpath("//div[@class='sidebar_inner dimension_tree']/div/ul/li"));

		// Get the count of check boxes
		int RowCount = allElements.size();
		for (int i = 0; i < RowCount; i++)
		{
			// Check the check boxes based on index
			//			DM_list[i] = allElements[i].getText();

		}


	}

}
